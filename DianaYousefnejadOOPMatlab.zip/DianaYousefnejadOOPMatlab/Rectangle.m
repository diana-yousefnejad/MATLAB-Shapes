classdef Rectangle <Shape & ColorMixin
    properties 
        length = []
        width = []
    end
    methods 
        function obj = Rectangle(length, width, color)
            obj@Shape("rectangle")
            obj@ColorMixin(color)
            obj.length = length
            obj.width = width
        end
    end
    methods 
        function obj = CalculateArea(obj)
            obj.area = obj.length * obj.width
            fprintf("area is %s", obj.area)
        end
    end
    methods 
        function display1(obj)
            fprintf("The area of a rectangle with a length of " + obj.length + " and width of " + obj.width + " is approximately " + obj.area + " square units.")
            fprintf(" The color of the rectangle is " + obj.color + ".")
           
        end
    end
    methods 
        function draw(obj)
            axis([0 12 0 12])
            rectangle('Position',[0 0 obj.length obj.width], 'FaceColor', obj.color)
            title('Rectangle Plot')
            annotation("textbox", [.5 .5 .2 .2], 'String', "length = " + obj.length )
            annotation("textbox", [.5 .5 .2 .15], 'String', "width = " + obj.width )
            annotation("textbox", [.5 .5 .2 .1], 'String', "area = " + obj.area )
            annotation("textbox", [.5 .5 .2 .05], 'String', "color = " + obj.color )
        end
    end
    
end