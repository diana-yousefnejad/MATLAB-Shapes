classdef EquilateralTriangle <Triangle
    
   properties
       side = []
       
   end
    methods 
        function obj = EquilateralTriangle(side, color)
            obj@Triangle(side, (side*sqrt(3)* 0.5), color)
            obj.side = side
            
        end
    end
     methods 
        function display1(obj)
            fprintf("The area of a triangle with a side length of " + obj.side + " is approximately " + obj.area + " square units." )
            fprintf(" The color of the triangle is " + obj.color)
        end
     end
     
    methods
        function draw(obj)
            x = [0, obj.side/2, obj.side]
            y = [0, obj.side, 0]
            plot(x,y)
            area(x, y, 'FaceColor', obj.color)
            title('Equilateral Triangle Plot')
            annotation("textbox", [.6 .6 .2 .15], 'String', "sidelength = " + obj.side )
            annotation("textbox", [.6 .6 .2 .1], 'String', "area = " + obj.area )
            annotation("textbox", [.6 .6 .2 .05], 'String', "color = " + obj.color )
            axis([0 10 0 10])
        end
    end
        

        
end
        