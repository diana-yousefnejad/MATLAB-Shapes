classdef Shape %< matlab.mixin.Heterogeneous
    properties 
        name = ""
        area = []
    end
   
    methods 
        %constructor
        function obj = Shape(initialname)
            obj.name = initialname;
        end
    end

    methods
       function display1(obj)
            fprintf("name is %s", obj.name);
        end

    end

    
    methods(Static) 
        function CalculateStatistics(shapes)
             areas = zeros(size(shapes))
             for i = 1:numel(shapes)
                 areas(i) = shapes(i).area
             end
             areaMean = mean(areas);
             fprintf("Mean of the areas of the shapes: " + areaMean )
             areaMedian = median(areas)
             fprintf("\nMedian of the areas of the shapes: " + areaMedian)
             areaStandardDeviation = std(areas);
             fprintf("\nStandard deviation of the areas of the shapes: " + areaStandardDeviation)
       end
   end
            
end 
        
        