classdef Triangle <Shape & ColorMixin
    properties 
        base = []
        height = []
    end
    methods 
        function obj = Triangle(base, height, color)
            obj@Shape("triangle")
            obj@ColorMixin(color)
            obj.base = base
            obj.height = height
        end
    end
    methods 
        function obj = CalculateArea(obj)
            obj.area = obj.base * obj.height * 0.5
            fprintf("area is %s", obj.area)
        end
    end
    methods 
        function display1(obj)
            fprintf("The area of a triangle with a base of " + obj.base + " and height of " + obj.height + " is approximately " + obj.area + " square units." )
            fprintf(" The color of the triangle is " + obj.color)
        end
    end
    
    methods 
        function draw(obj)
            x = [0, obj.base/2, obj.base]
            y = [0, obj.height, 0]
            plot(x,y)
            area(x, y, 'FaceColor', obj.color)
            title('Triangle Plot')
            annotation("textbox", [.6 .6 .2 .2], 'String', "base = " + obj.base )
            annotation("textbox", [.6 .6 .2 .15], 'String', "height = " + obj.height )
            annotation("textbox", [.6 .6 .2 .1], 'String', "area = " + obj.area )
            annotation("textbox", [.6 .6 .2 .05], 'String', "color = " + obj.color )
            axis([0 10 0 10])
        end
    end
        
end