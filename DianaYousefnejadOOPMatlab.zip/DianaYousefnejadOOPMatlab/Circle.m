classdef Circle <Shape & ColorMixin
    properties 
        radius =[]
    end
    methods 
        function obj = Circle(radius, color)
            obj@Shape("circle")
            obj@ColorMixin(color)
            obj.radius = radius
        end
    end
    
    methods 
        function obj = CalculateArea(obj)
            obj.area = pi * obj.radius^2
            fprintf("area is %s", obj.area)
        end
    end
    methods 
        function display1(obj)
            fprintf("The area of a circle with a radius of " + obj.radius + " is approximately " + obj.area + " sqaure units.")
            fprintf(" The circle's color is " + obj.color +"." )
        end
    end
    methods 
        function draw(obj)
            axis([0 10 0 10])
            rectangle('Position', [0 0 2* obj.radius 2* obj.radius], 'FaceColor', obj.color, 'Curvature', [1,1])
            title("Circle Plot")
            annotation("textbox", [.6 .6 .2 .15], 'String', "area = " + obj.area )
            annotation("textbox", [.6 .6 .2 .1], 'String', "radius = " + obj.radius )
            annotation("textbox", [.6 .6 .2 .05], 'String', "color = " + obj.color )
        end
    end

end
            
    