classdef ColorMixin 
    
    properties 
        color = ""
    end
    
    
    methods 
        %constructor
        function obj = ColorMixin(color)
            obj.color = color;
        end
    end
    
    methods
        function color = getColor(obj)
            color = obj.color;
        end
    end
    
    methods
        function obj = setColor(obj, newColor)
            obj.color = newColor;
            
        end
    end
end
            
            