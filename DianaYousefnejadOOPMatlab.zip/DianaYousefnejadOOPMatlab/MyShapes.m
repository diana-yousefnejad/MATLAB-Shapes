fprintf("Please select one of the four available shapes by entering corresponding number\n")
fprintf("1. circle \n")
fprintf("2. rectangle \n")
fprintf("3. triangle \n")
fprintf("4. equilateral triangle \n")
userinput = input("Enter here")


switch userinput
    
    case 1 
        radius = input('Enter radius for your circle: \n');
        color = input('Enter the color of your circle in quotation marks: \n');
        usercircle = Circle(radius,color);
        usercircle = CalculateArea(usercircle);
        
        draw(usercircle);
    case 2 
        length = input('Enter the length of your rectangle: \n');
        width = input('Enter the width of your rectangle: \n');
        color = input('Enter the color of your rectangle in quotation marks: \n');
        userrectangle = Rectangle(length, width, color);
        userrectangle = CalculateArea(userrectangle);
        draw(userrectangle);
        
   case 3 
        base = input('Enter the base of your triangle: \n');
        height = input('Enter the height of your triangle: \n');
        color = input('Enter the color of your triangle in quotation marks: \n');
        usertriangle = Triangle(base, height, color);
        usertriangle = CalculateArea(usertriangle);
        draw(usertriangle); 
       
   case 4 
        side = input('Enter the side length of your equilateral triangle: \n');
        color = input('Enter the color of your equilateral triangle in quotation marks: \n');
        userequilateraltriangle = EquilateralTriangle(side, color);
        userequilateraltriangle = CalculateArea(userequilateraltriangle);
        draw(userequilateraltriangle); 
end
  
        
        
        